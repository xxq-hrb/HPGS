import argparse
import os
import sys
import time
from collections import defaultdict

import dill
import numpy as np
import torch
from sklearn.model_selection import train_test_split
import torch.nn as nn
from torch_geometric.data import Data
from torch_sparse import SparseTensor

from HGCNMULTI import HGCNMHR
from model import MultiATHR
from util import presDataset, llprint, multi_label_metric
import torch.nn.functional as F

MODEL_NAME = 'MUATHR'
# def llprint(message):
#     sys.stdout.write(message)
#     sys.stdout.flush()
# def print_to_log(string, log_fp):
#     llprint(string)
#     print(string, file=log_fp)

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--eval', action='store_true', default=False, help="eval mode")
    parser.add_argument('--model_name', type=str, default=MODEL_NAME, help="model name")
    parser.add_argument('--ddi', action='store_true', default=False, help="using ddi")
    parser.add_argument('--voc_path', type=str, default='./data/voc_final.pkl', help='Vocab path to load.')
    parser.add_argument('--ddi_path', type=str, default='./data/ddi_A_final.pkl', help='DDI table to look up.')
    parser.add_argument('--upper_med_path', type=str, default='./data/hire_data/med_h.pkl', help='Vocab for upper level medications.')
    parser.add_argument('--data_dir', type=str, default='./data/hire_data/', help='Dataset dir.')
    parser.add_argument('--num_epoch', type=int, default=25, help='Number of training epochs.')
    parser.add_argument('--lr', type=float, default=0.000009, help='Learning rate.')
    parser.add_argument('--device', type=str, default='cuda', help='Running device.')
    parser.add_argument('--weight_path', type=str, default='', help='Model weight path for predicting.')
    parser.add_argument('--TS_type', type=str, default='exp', help='Training scheduler type.')
    parser.add_argument('--CL_Train', action='store_true', default=True, help='Set true to start SGCL algorithm.')
    parser.add_argument('--Ehr_path', type=str, default='./data/', help='set the path of ehr graph')
    args = parser.parse_args()


    return args
arg = get_args()
devices = arg.device



def main():
    sh_edge = np.load('./data/sh_graph.npy')
    sh_edge = sh_edge.tolist()
    sh_edge_index = torch.tensor(sh_edge, dtype=torch.long)
    sh_x = torch.tensor([[i] for i in range(2322)], dtype=torch.float)
    sh_data = Data(x=sh_x, edge_index=sh_edge_index.t().contiguous()).to(device=devices)
    sh_data_adj = SparseTensor(row=sh_data.edge_index[0], col=sh_data.edge_index[1],
                               sparse_sizes=(2322, 2322))
    sh_data_row, sh_data_col = sh_data.edge_index[0], sh_data.edge_index[1]
    sh_data_values = torch.ones(17576).to(devices)
    sh_data_size = (2322, 2322)
    sh_data_s = torch.sparse_coo_tensor(indices=torch.stack([sh_data_row, sh_data_col]), values=sh_data_values,size=sh_data_size).to(devices)

    # S-S G
    ss_edge = np.load('./data/ss_graph.npy')
    ss_edge = ss_edge.tolist()
    ss_edge_index = torch.tensor(ss_edge, dtype=torch.long)
    ss_x = torch.tensor([[i] for i in range(1366)], dtype=torch.float)
    ss_data = Data(x=ss_x, edge_index=ss_edge_index.t().contiguous()).to(devices)
    ss_data_adj = SparseTensor(row=ss_data.edge_index[0], col=ss_data.edge_index[1],
                               sparse_sizes=(1366, 1366))
    ss_data_row, ss_data_col = ss_data.edge_index[0], ss_data.edge_index[1]
    ss_data_values = torch.ones(14292).to(devices)
    ss_data_size = (1366,1366)
    ss_data_s = torch.sparse_coo_tensor(indices=torch.stack([ss_data_row, ss_data_col]), values=ss_data_values,
                                        size=ss_data_size).to(devices)

    # H-H G
    hh_edge = np.load('./data/hh_graph.npy').tolist()
    hh_edge_index = torch.tensor(hh_edge, dtype=torch.long)   # 边索引需要减去390
    hh_x = torch.tensor([[i] for i in range(1366, 2322)], dtype=torch.float)
    hh_data = Data(x=hh_x, edge_index=hh_edge_index.t().contiguous()).to(devices)
    hh_data_adj = SparseTensor(row=hh_data.edge_index[0], col=hh_data.edge_index[1],
                               sparse_sizes=(956, 956))
    hh_data_row, hh_data_col = hh_data.edge_index[0], hh_data.edge_index[1]
    hh_data_values = torch.ones(8238).to(devices)
    hh_data_size = (956,956)
    hh_data_s = torch.sparse_coo_tensor(indices=torch.stack([hh_data_row, hh_data_col]), values=hh_data_values,
                                        size=hh_data_size).to(devices)

    #DDIG
    hd_edge = np.load('./data/ddi_graph.npy').tolist()
    hd_edge_index = torch.tensor(hd_edge,dtype=torch.long)
    hd_x = torch.tensor([[i] for i in range(1366, 2322)], dtype=torch.float)
    hd_data = Data(x=hd_x, edge_index=hd_edge_index.t().contiguous()).to(devices)
    hd_data_row, hd_data_col = hd_data.edge_index[0], hd_data.edge_index[1]
    hd_data_values = torch.ones(31).to(devices)
    hd_data_size = (956,956)
    hd_data_s = torch.sparse_coo_tensor(indices=torch.stack([hd_data_row, hd_data_col]), values=hd_data_values,
                                        size=hd_data_size).to(devices)


    args = get_args()
    voc_size=(1366,956)
    data = dill.load(open('./data/prescript.pkl','rb'))
        # print((data[0][0][1]))
    model_name = args.model_name
    if not os.path.exists(os.path.join("saved", model_name)):
        os.makedirs(os.path.join("saved", model_name))
    log_path = os.path.join("saved", model_name,
                            '%s.log' % time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime()))
    log_fp = open(log_path, 'w')
    # print(str(args) + '\n', log_fp)
    p_list = [x for x in range(len(data))]
    train_data,dev_test_data = train_test_split(p_list,test_size=0.2,shuffle=True)
    dev_data,test_data = train_test_split(dev_test_data,test_size=1-0.5,shuffle=False)
    train_dataset = []
    dev_dataset = []
    test_dataset=[]
    for index in train_data:
        train_dataset.append(data[index])
    for index in dev_data:
        dev_dataset.append(data[index])
    for index in test_data:
        test_dataset.append(data[index])

    EPOCH = args.num_epoch
    LR = args.lr
    device = torch.device(args.device)
    model = HGCNMHR(1366,956,2322,16,1).to(devices)
    criterion = torch.nn.BCEWithLogitsLoss(reduction="mean")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr,weight_decay=0.8)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=25, gamma=0.5)
    epsilon = 1e-13
    T = 0.5
    decay_weight = 0.85
    class ContrastiveLoss(nn.Module):
        def __init__(self, margin, device):
            super(ContrastiveLoss, self).__init__()
            self.margin = margin
            self.eps = 1e-9
            self.device = device  ### (1-1matched)= target

            ##1.0

        def forward(self, output1, output2, target, size_average=True):
            # print(' we are shape') ##torch.Size([20, 100])torch.Size([20, 100])torch.Size([20])
            target = target.to(self.device)
            distances = (output2 - output1).pow(2).sum(1).to(self.device)  # squared distances
            losses = 0.5 * (target.float() * distances +
                            (1 + -1 * target).float() * F.relu(self.margin - (distances + self.eps).sqrt()).pow(2))
            # print(losses)
            # print("i am lossses")
            # if (losses.mean()).item()
            #     losses =  F.kl_div(F.log_softmax(output1, dim=-1), F.softmax(query, dim=-1), reduction='none')
            #     return 100*losses.mean()
            # else:
            return losses.mean() if size_average else losses.sum()

    def eval(model, data_eval, ss_data,sh_data,hh_data,voc_size, epoch):
        # evaluate

        model.eval()
        smm_record = []
        ja, prauc, avg_p, avg_r, avg_f1 = [[] for _ in range(5)]
        case_study = defaultdict(dict)
        med_cnt = 0
        visit_cnt = 0
        for step,input in enumerate(train_dataset):
            y_gt = []
            y_pred = []
            y_pred_prob = []
            y_pred_label = []
            for idx,adm in enumerate(input):
                seq_input = input[:idx+1]
                loss_li_target = np.zeros((1,voc_size[1]))
                loss_li_target[:,adm[1]] = 1
                outputs = model(sh_data.x,sh_data.edge_index,ss_data.x,ss_data.edge_index,hh_data.x,hh_data.edge_index,seq_input)
                y_gt_tmp = np.zeros(voc_size[1])
                y_gt_tmp[adm[1]] = 1
                y_gt.append(y_gt_tmp)

                target_output1 = F.sigmoid(outputs).detach().cpu().numpy()[0]
                y_pred_prob.append(target_output1)
                y_pred_tmp = target_output1.copy()
                y_pred_tmp[y_pred_tmp >= 0.5] = 1
                y_pred_tmp[y_pred_tmp < 0.5] = 0
                y_pred.append(y_pred_tmp)
                y_pred_label_tmp = np.where(y_pred_tmp == 1)[0]
                y_pred_label.append(sorted(y_pred_label_tmp))
                visit_cnt += 1
                med_cnt += len(y_pred_label_tmp)

            smm_record.append(y_pred_label)
            adm_ja, adm_prauc, adm_avg_p, adm_avg_r, adm_avg_f1 = multi_label_metric(np.array(y_gt), np.array(y_pred),
                                                                                     np.array(y_pred_prob))
            case_study[adm_ja] = {'ja': adm_ja, 'patient': input, 'y_label': y_pred_label}

            ja.append(adm_ja)
            prauc.append(adm_prauc)
            avg_p.append(adm_avg_p)
            avg_r.append(adm_avg_r)
            avg_f1.append(adm_avg_f1)
            llprint('\rEval--Epoch: %d, Step: %d/%d' % (epoch, step, len(data_eval)))

            # ddi rate
            # ddi_rate = ddi_rate_score(smm_record)

        llprint('\tJaccard: %.4f,  PRAUC: %.4f, AVG_PRC: %.4f, AVG_RECALL: %.4f, AVG_F1: %.4f\n' % (
            np.mean(ja), np.mean(prauc), np.mean(avg_p), np.mean(avg_r), np.mean(avg_f1)
        ))
        # dill.dump(obj=smm_record, file=open('../data/gamenet_records.pkl', 'wb'))
        dill.dump(case_study, open(os.path.join('saved', model_name, 'case_study.pkl'), 'wb'))

        # print('avg med', med_cnt / visit_cnt)

        return np.mean(ja), np.mean(prauc), np.mean(avg_p), np.mean(avg_r), np.mean(avg_f1)


    contra_loss = ContrastiveLoss(1.5, device='cuda')
    history = defaultdict(list)
    best_ja = 0
    for epoch in range(EPOCH):

        loss_record=[]
        start_time = time.time()
        strat_time = time.time()
        model.train()
        running_loss = 0
        for step,input in enumerate(train_dataset):
            for idx,adm in enumerate(input):
                seq_input = input[:idx+1]
                loss_li_target = np.zeros((1,voc_size[1]))
                loss_li_target[:,adm[1]] = 1
                outputs,a,b = model(sh_data.x,sh_data_s,ss_data.x,ss_data_s,hh_data.x,hh_data_s,hd_data_s,seq_input)
                loss = criterion(outputs,torch.FloatTensor(loss_li_target).to(device))
                loss1 = contra_loss(a,b,torch.FloatTensor(loss_li_target))
                loss = 1.1*loss+0.1*loss1  #g公式4-39
                # print(outputs)
                loss.backward()
                optimizer.step()
                running_loss+=loss.item()
                loss_record.append(loss.item())
        scheduler.step()

    #     print('[Epoch {}]train_loss: '.format(epoch + 1), running_loss / len(train_dataset))
    #     T *= decay_weight
    #
    #     ja, prauc, avg_p, avg_r, avg_f1 = eval(model, dev_dataset, ss_data,sh_data,hh_data,voc_size, epoch)
    #
    #     history['ja'].append(ja)
    #     history['avg_p'].append(avg_p)
    #     history['avg_r'].append(avg_r)
    #     history['avg_f1'].append(avg_f1)
    #     history['prauc'].append(prauc)
    #
    #     end_time = time.time()
    #     elapsed_time = (end_time - start_time) / 60
    #     llprint('\tEpoch: %d, Loss: %.4f, One Epoch Time: %.2fm, Appro Left Time: %.2fh\n' % (epoch,
    #                                                                                           np.mean(loss_record),
    #                                                                                           elapsed_time,
    #                                                                                           elapsed_time * (
    #                                                                                                   EPOCH - epoch - 1) / 60))
    #
    #     torch.save(model.state_dict(),
    #                open(os.path.join('saved', model_name, 'Epoch_%d_JA_%.4f.model' % (epoch, ja)),
    #                     'wb'))
    #     print('')
    #     if epoch != 0 and best_ja < ja:
    #         best_epoch = epoch
    #         best_ja = ja
    #
    # dill.dump(history, open(os.path.join('saved', model_name, 'history.pkl'), 'wb'))
    #
    # # test
    # torch.save(model.state_dict(), open(
    #     os.path.join('saved', model_name, 'final.model'), 'wb'))
    #
    # print('best_epoch:', best_epoch)
        model.eval()
        dev_loss = 0

        # dev_p5 = 0
        # dev_p10 = 0
        # dev_p20 = 0
        #
        # dev_r5 = 0
        # dev_r10 = 0
        # dev_r20 = 0
        #
        # dev_f1_5 = 0
        # dev_f1_10 = 0
        # dev_f1_20 = 0
        ADMS_dev=[]
        true_lable_dev=[]
        for step, input in enumerate(dev_dataset):
            for idx, adm in enumerate(input):
                ADMS_dev.append(adm[1])
            for adms in ADMS_dev:
                for a in adms:
                    true_lable_dev.append(a)
            for idx,adm in enumerate(input):
                seq_input = input[:idx+1]
                loss_li_target = np.zeros((1,voc_size[1]))
                loss_li_target[:,adm[1]] = 1
                # outputs = model(sh_data.x,sh_data.edge_index,ss_data.x,ss_data.edge_index,hh_data.x,hh_data.edge_index,seq_input)
                outputs,a,b = model(sh_data.x,sh_data_s,ss_data.x,ss_data_s,hh_data.x,hh_data_s,hd_data_s,seq_input)

                loss = criterion(outputs,torch.FloatTensor(loss_li_target).to(device))
                loss1 = contra_loss(a,b,torch.FloatTensor(loss_li_target))
                loss = 0.9*loss+0.1*loss1
                dev_loss+=loss.item()
                # top5=torch.topk(outputs,5)[1]
                # # print(top5)
                # # print(adm[1])
                # count=0
                # for m in top5[0]:
                #     if m in adm[1]:
                #         count+=1
                # dev_p5+=count/5
                # dev_r5+=count/len(adm[1])
                #
                # top10 = torch.topk(outputs, 10)[1]
                # # print(top5)
                # # print(adm[1])
                # count = 0
                # for m in top10[0]:
                #     if m in adm[1]:
                #         count += 1
                # dev_p10 += count / 10
                # dev_r10 += count / len(adm[1])
                #
                # top20 = torch.topk(outputs, 20)[1]
                # # print(top5)
                # # print(adm[1])
                # count = 0
                # for m in top20[0]:
                #     if m in adm[1]:
                #         count += 1
                # dev_p20 += count / 20
                # dev_r20 += count / len(adm[1])

        print('[Epoch {}]dev_loss: '.format(epoch + 1), dev_loss / len(dev_dataset))
            # print('[Epoch {}]dev_loss: '.format(epoch + 1), dev_loss / len(x_dev))
        # print('p5-10-20:', dev_p5 / len(dev_dataset),dev_p10/len(dev_dataset),dev_p20/len(dev_dataset))
        # print('r5-10-20:', dev_r5 / len(dev_dataset), dev_r10 / len(dev_dataset), dev_r20 / len(dev_dataset))
        # print('f1_5-10-20: ',
        #       2 * (dev_p5 / len(dev_dataset)) * (dev_r5 / len(dev_dataset)) / (
        #                   (dev_p5 / len(dev_dataset)) + (dev_r5 / len(dev_data)) + epsilon),
        #       2 * (dev_p10 / len(dev_dataset)) * (dev_r10 / len(dev_dataset)) / (
        #                   (dev_p10 / len(dev_dataset)) + (dev_r10 / len(dev_dataset)) + epsilon),
        #       2 * (dev_p20 / len(dev_dataset)) * (dev_r20 / len(dev_dataset)) / (
        #                   (dev_p20 / len(dev_dataset)) + (dev_r20 / len(dev_dataset)) + epsilon))
    model.eval()
    test_loss = 0

    test_p5 = 0
    test_p10 = 0
    test_p20 = 0

    test_r5 = 0
    test_r10 = 0
    test_r20 = 0

    test_f1_5 = 0
    test_f1_10 = 0
    test_f1_20 = 0
    ADMS_T=[]
    true_lable_test=[]
    for step, input in enumerate(test_dataset):
        for idx, adm in enumerate(input):
            ADMS_T.append(adm[1])
        for adms in ADMS_dev:
            for a in adms:
                true_lable_test.append(a)

        for idx, adm in enumerate(input):
            seq_input = input[:idx + 1]
            loss_li_target = np.zeros((1, voc_size[1]))
            loss_li_target[:, adm[1]] = 1
            # outputs = model(sh_data.x, sh_data.edge_index, ss_data.x, ss_data.edge_index, hh_data.x, hh_data.edge_index,
            #                 seq_input)
            outputs, a, b = model(sh_data.x, sh_data_s, ss_data.x, ss_data_s, hh_data.x, hh_data_s, hd_data_s,
                                  seq_input)

            loss = criterion(outputs, torch.FloatTensor(loss_li_target).to(device))
            loss1 = contra_loss(a,b,torch.FloatTensor(loss_li_target))
            loss = 0.9*loss+0.1*loss1
            test_loss+= loss.item()
            top5 = torch.topk(outputs, 5)[1]
            # print(top5)
            # print(adm[1])
            count = 0
            for m in top5[0]:
                if m in adm[1]:
                    count += 1
            test_p5 += count / 5
            test_r5 += count / len(adm[1])

            top10 = torch.topk(outputs, 10)[1]
            # print(top5)
            # print(adm[1])
            count = 0
            for m in top10[0]:
                if m in adm[1]:
                    count += 1
            test_p10 += count / 10
            test_r10 += count / len(adm[1])

            top20 = torch.topk(outputs, 20)[1]
            # print(top5)
            # print(adm[1])
            count = 0
            for m in top20[0]:
                if m in adm[1]:
                    count += 1
            test_p20 += count / 20
            test_r20 += count / len(adm[1])


    print("--------------------------------------------------------------------------------------------------------")
    print('test_loss: ',test_loss/ len(test_dataset))
    # print('[Epoch {}]dev_loss: '.format(epoch + 1), dev_loss / len(x_dev))
    print('p5-10-20:', test_p5/ len(test_dataset), test_p10 / len(test_dataset), test_p20 / len(test_dataset))
    print('r5-10-20:', test_r5 / len(test_dataset), test_r10 / len(test_dataset), test_r20 / len(test_dataset))
    print('f1_5-10-20: ',
          2 * (test_p5 / len(test_dataset)) * (test_r5 / len(test_dataset)) / ((test_p5 / len(test_dataset)) + (test_r5 / len(test_dataset))),
          2 * (test_p10 / len(test_dataset)) * (test_r10 / len(test_dataset)) / (
                      (test_p10 / len(test_dataset)) + (test_r10 / len(test_dataset))),
          2 * (test_p20 / len(test_dataset)) * (test_r20 / len(test_dataset)) / (
                      (test_p20 / len(test_dataset)) + (test_r20 / len(test_dataset))))

#
#
if __name__=='__main__':
    main()