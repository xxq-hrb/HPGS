import math

import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score
import torch
import torch.nn as nn
import torch.nn.functional as F

from layers.layers import FermiDiracDecoder
import layers.hyp_layers as hyp_layers
import manifolds
import models.encoders as encoders
from models.decoders import model2decoder

class RETAIN(nn.Module):
    def __init__(self, emb_dim):
        super(RETAIN, self).__init__()
        self.emb_dim = emb_dim
        self.encoder = nn.GRU(emb_dim, emb_dim * 2, batch_first=True)
        self.alpha_net = nn.Linear(emb_dim * 2, 1)
        self.beta_net = nn.Linear(emb_dim * 2, emb_dim)

    def forward(self, i1_seq):
        o1, h1 = self.encoder(i1_seq)                     # o1:(1, seq, dim*2) hi:(1,1,dim*2)

        ej1 = self.alpha_net(o1)                          # (1, seq, 1)
        bj1 = self.beta_net(o1)                           # (1, seq, dim)
        att_ej1 = torch.softmax(ej1, dim=1)
        o1 = att_ej1 * torch.tanh(bj1) * i1_seq # (1, dim)

        return o1,h1
class NCModel(nn.Module):
    """
    Base model for node classification task.
    """

    def __init__(self, n_nodes,output_dim):
        super(NCModel, self).__init__()
        self.c = torch.tensor([2.])
        self.manifold= 'PoincareBall'
        self.encoder = getattr(encoders, 'HGCN')(self.c)
        self.decoder = model2decoder['HGCN'](self.c)

    def encode(self, x, adj):
        if self.manifold == 'Hyperboloid':
            o = torch.zeros_like(x)
            x = torch.cat([o[:, 0:1], x], dim=1)
        h = self.encoder.encode(x, adj)
        return h

    def decode(self, h, adj):
        output = self.decoder.decode(h, adj)
        return output
        # return F.log_softmax(output[idx], dim=1)

    def compute_metrics(self, embeddings, data):
        # idx = data[f'idx_{split}']
        # output = self.decode(embeddings, data['adj_train_norm'])
        output = self.decode(embeddings,data)
        # loss = F.nll_loss(output, data['labels'][idx], self.weights)
        # acc, f1 = acc_f1(output, data['labels'][idx], average=self.f1_average)
        # metrics = {'loss': loss, 'acc': acc, 'f1': f1}
        return output
class HGCNMHR(torch.nn.Module):
    def __init__(self, ss_num, hh_num, sh_num, embedding_dim, batchSize):
        super(HGCNMHR, self).__init__()
        self.batchSize = batchSize
        # self.drop = drop
        self.voc_size=(ss_num,hh_num)

        self.SH_embedding = torch.nn.Embedding(sh_num, embedding_dim)
        self.SS_embedding = torch.nn.Embedding(ss_num,embedding_dim)
        self.HH_embedding = torch.nn.Embedding(sh_num,embedding_dim)

        # S-H 图所需的网络
        # S
        self.HGCNSS_Embedding=NCModel(n_nodes=ss_num,output_dim=embedding_dim)
        self.HGCNSH_Embedding = NCModel(n_nodes=sh_num,output_dim=embedding_dim)
        self.HGCNSH_Embedding2 = NCModel(n_nodes=sh_num, output_dim=embedding_dim)
        self.HGCNHH_Embedding=NCModel(n_nodes=hh_num,output_dim=embedding_dim)
        self.sh_ems=torch.nn.Linear(16,16)
        self.SH_mlp_1 = torch.nn.Linear(16, 16)

        self.SH_bn_1_h = torch.nn.BatchNorm1d(16)
        self.SH_tanh_1_h = torch.nn.Tanh()

        self.concatsLinear = torch.nn.Linear(16*2,16)
        self.concathLinear = torch.nn.Linear(16*2,16)


        self.Ls = torch.nn.Linear(16,16)#32+27
        # self.L = torch.nn.Linear(32, 32)  # 32+27
        self.mlp = torch.nn.Linear(16, 16)
        self.SI_bn = torch.nn.BatchNorm1d(16)
        self.relu = torch.nn.ReLU()


        #20240402
        self.conv_ddi=NCModel(n_nodes=hh_num,output_dim=embedding_dim)
        self.retain = nn.ModuleList([RETAIN(256) for _ in range(2)])
        self.getmedecine = nn.Linear(64, 956)
        self.herbs = nn.Linear(256, 956)
        self.L = nn.Linear(576, 956)
        self.K = nn.Linear(956, 256)
        self.P = nn.Linear(512, 256)
        self.med_embedding = nn.Sequential(
            nn.ReLU(),
            nn.Linear(256, embedding_dim),
            nn.Dropout(0.5)
        )
        self.query = nn.Sequential(
            nn.ReLU(),
            nn.Linear(512, 256),
        )
        self.nhead = 2

        #self.medication_encoder = nn.TransformerEncoderLayer(64, self.nhead, batch_first=True, dropout=0.2)
        self.medication_encoder = nn.TransformerEncoderLayer(64, self.nhead, dropout=0.2)
        self.MED_PAD_TOKEN = hh_num + 2
        self.med_embedding = nn.Linear(512, 64)
        # self.med_embedding = (
        #     nn.Sequential(
        #     # 添加padding_idx，表示取0向量
        #     nn.Embedding(voc_size[1] + 3, emb_dim, self.MED_PAD_TOKEN),
        #     nn.Dropout(0.3)
        # ))
        self.tran = nn.Linear(4096, 956)
        self.abc = nn.Linear(256 * 2, 256)

        self.sample = nn.Linear(256, 1)
        self.sample2 = nn.Linear(16, 1)  # 2024
        # self.sample3 = nn.Linear(112, 1)

        self.output = nn.Sequential(
            nn.ReLU(),
            # nn.Linear(256 * 3, embedding_dim * 2),
            nn.Linear(256*2 , embedding_dim * 2),
            nn.ReLU(),
            nn.Linear(embedding_dim * 2, hh_num)
        )

        self.embeddings = nn.ModuleList(
            [nn.Embedding(self.voc_size[i], 256) for i in range(2)])
        self.xh_encode=nn.Linear(16,256)
        self.xs_encode = nn.Linear(16,256)
        self.dropout = nn.Dropout(0.7)
        self.device = 'cuda'
    def calc_cross_visit_scores(self, visit_diag_embedding):
        """
        visit_diag_embedding: (batch * visit_num * emb)
        visit_proc_embedding: (batch * visit_num * emb)
        """
        max_visit_num = visit_diag_embedding.size(1)
        batch_size = visit_diag_embedding.size(0)
        new = visit_diag_embedding.size(2)
        # mask表示每个visit只能看到自己之前的visit
        mask = (torch.triu(torch.ones((max_visit_num, max_visit_num), device=self.device)) == 1).transpose(0,                                                                                                 1)  # 返回一个下三角矩阵
        mask = mask.float().masked_fill(mask == 0, -1e9).masked_fill(mask == 1, float(0.0))
        mask = mask.unsqueeze(0).repeat(batch_size, 1, 1)
        # 每个visit后移一位
        padding = torch.zeros((batch_size, 1, new), device=self.device).float()
        # print(visit_diag_embedding.shape,'qqqqqqqq')
        # print(padding.shape,'wwwwww')
        diag_keys = torch.cat([padding, visit_diag_embedding[:, :-1, :]], dim=1)  # batch * max_visit_num * emb
        # 得到每个visit跟自己前面所有visit的score
        diag_scores = torch.matmul(visit_diag_embedding, diag_keys.transpose(-2, -1)) \
                      / math.sqrt(visit_diag_embedding.size(-1))
        # 1st visit's scores is not zero!
        scores = F.softmax(diag_scores + mask, dim=-1)
        ###### case study
        # 将第0个val置0，然后重新归一化
        # scores_buf = scores
        # scores_buf[:, :, 0] = 0.
        # scores_buf = scores_buf / torch.sum(scores_buf, dim=2, keepdim=True)
        # print(scores_buf)
        return scores


    def forward(self, x_SH, Spare_SH,x_SS,Spare_SS,x_HH,Spare_HH,Spare_ddi, input):
        def mean_embedding(embedding):
            return  embedding.mean(dim=1).unsqueeze(dim=0)
        if len(input)==0:
            raise Exception("Input error")

        def getindex(list,nums):
            x = [0]*nums
            for d in list:
                x[d]=1
            x = torch.LongTensor(x)
            return x
        # S-H图搭建
        # 第一层
        x_SH1 = self.SH_embedding(x_SH.long())
        x_SH2 = self.HGCNSH_Embedding.encode(x_SH1.squeeze(), Spare_SH)
        x_SH2=self.HGCNSH_Embedding.compute_metrics(x_SH2,Spare_SH)
        # x_SH4 = self.HGCNSH_Embedding2.encode(x_SH2,Spare_SH)#20240330
        # x_SH5 = self.HGCNSH_Embedding2.compute_metrics(x_SH4,Spare_SH)#20240330
        x_SH3 = self.sh_ems(x_SH1.squeeze())
        x_SH2 = (x_SH2+x_SH3)/2.0
        x_SH2 = self.SH_mlp_1(x_SH2)
        x_SH2=self.SH_bn_1_h(x_SH2)
        x_SH2 = self.SH_tanh_1_h(x_SH2)
        #S-S
        x_ss1 = self.SS_embedding(x_SS.long())
        x_ss2 = self.HGCNSS_Embedding.encode(x_ss1.squeeze(), Spare_SS)
        x_ss2 = self.HGCNSS_Embedding.compute_metrics(x_ss2, Spare_SS)

        #HH

        x_hh1 = self.HH_embedding(x_HH.long())
        x_hh2 = self.HGCNHH_Embedding.encode(x_hh1.squeeze(),Spare_HH)
        x_hh2 = self.HGCNHH_Embedding.compute_metrics(x_hh2,Spare_HH)
        # x_hh2 = torch.cat((x_hh2.float(), kgOneHot), dim=-1)

        x_hh2 = self.Ls(x_hh2)

        # concat
        # es = torch.concat([x_SH2[:390],x_ss2],dim=1)
        # es = self.concatsLinear(es)
        # es =  x_SH2[:390]
        # eh = torch.concat([x_SH2[390:],x_hh2],dim=1)
        # eh = self.concathLinear(eh)
        x_hddi = self.conv_ddi.encode(x_hh1.squeeze(), Spare_ddi)
        x_ddi = self.conv_ddi.compute_metrics(x_hddi,Spare_ddi)
        es = (x_SH2[:1366] + x_ss2) / 2.0
        eh = (x_SH2[1366:] + x_hh2) / 2.0-0.1*x_ddi
        es = self.xs_encode(es)
        eh = self.xh_encode(eh)

        #mok
        i1_seq = []
        i2_seq = []
        for adm in input:
            # i1 = mean_embedding(self.dropout(
            #     self.embeddings[0](torch.LongTensor(adm[0]).unsqueeze(dim=0).to(self.device))))  # (1,1,dim)
            # i2 = mean_embedding(
            #     self.dropout(self.embeddings[1](torch.LongTensor(adm[1]).unsqueeze(dim=0).to(self.device))))
            i1 = self.dropout(
                torch.mm(getindex(adm[0], 1366).unsqueeze(dim=0).float().to(self.device), es).to(self.device))
            i2 = torch.mm(getindex(adm[1], 956).unsqueeze(dim=0).float().to(self.device), eh)
            i1_seq.append(mean_embedding(i1.unsqueeze(dim=0)))
            i2_seq.append(mean_embedding(i2.unsqueeze(dim=0)))
            # i2_seq.append(mean_embedding(i2))
        i1_seq = torch.cat(list(reversed(i1_seq)), dim=1)
        # i2_seq = torch.cat(list(reversed(i2_seq)),dim=1)
        o1, h1 = self.retain[0](i1_seq)
        # 历史用药距离计算模块
        visit_diag_embedding = o1.view(64, 1, -1)
        cross_visit_scores = self.calc_cross_visit_scores(visit_diag_embedding)
        prob_g = F.softmax(cross_visit_scores, dim=-1)
        patient_representations = torch.cat([o1, o1], dim=-1).squeeze(dim=0)
        queries = self.query(patient_representations)
        query = queries[-1:]
        history_values = np.zeros((len(input) - 1, 956))
        b = torch.zeros(1, 956).to(self.device)
        if len(input) > 1:
            i2_seq = torch.cat(list(reversed(i2_seq[:-1])), dim=1)
            o2, h2 = self.retain[1](i2_seq)
            last_seq_medication = h2
            last_seq_medication_emb = self.med_embedding(last_seq_medication)
            # last_seq_medication_emb = torch.squeeze(last_seq_medication_emb)
            # last_seq_medication_emb = torch.squeeze(last_seq_medication_emb)
            encoded_medication = self.medication_encoder(last_seq_medication_emb, src_mask=None)
            prob_g = prob_g.squeeze(dim=1)
            history_keys = query
            # history_values = np.zeros((len(input) - 1, self.vocab_size[1]))
            b = prob_g * encoded_medication.squeeze(dim=1)
            b = b.view(1, -1)
            b = self.tran(b)
            for idx, adm in enumerate(input):
                if idx == len(input) - 1:
                    break
                history_values[idx, adm[1]] = 1
                history_items = torch.mm(torch.Tensor(history_values).to(self.device), eh)
                # history_items_med = self.retain[1](history_items.unsqueeze(0))
            history_values = torch.FloatTensor(history_values).to(self.device)
        fun2 = torch.mm(query, eh.t())
        key_weights1 = F.softmax(torch.mm(query, eh.t()), dim=-1)  # (1, size)
        fact1 = torch.mm(key_weights1, eh)  # (1, dim)
        w1 = torch.sigmoid(fun2)
        #     feat = torch.cat([i1_emb,  query,history_items_med], dim=-1)
        if len(input) > 1:
            history_keys = queries[:(queries.size(0) - 1)]
            visit_weight = F.softmax(torch.mm(query, history_keys.t()), dim=-1)  # (1, seq-1)
            weighted_values = visit_weight.mm(history_values)  # (1, size)

            fact2 = torch.mm(weighted_values, eh)
        else:
            fact2 = fact1
        # fact2 = fact1
        # output = self.output(torch.cat([query, fact1, fact2], dim=-1))
        output = self.output(torch.cat([query, fact1], dim=-1))
        a = w1 * (0.9 * output) + 1.85 * b
        # a=output
        ehr_graph = self.sample(eh)
        # ehr_graph = self.sample2(ehr_graph)
        ddi_graph = self.sample2(x_hddi)
        # ddi_graph = self.sample2(ddi_graph)
        # ehr_graph = self.sample3(ehr_graph)
        fin_e = ehr_graph.t()
        fin_d = ddi_graph.t()
        return a, fin_e, fin_d

