# HPGS

This repository is the implementation of HPGS:

Hyperbolic Multi-Graph Neural Network Based Generative Search for Chinese Herb Prescriptions
# Required packages

torch == 1.5.0+cpu

torch-geometric == 1.4.3 or higher  #z这个位置

numpy == 1.18.1 #这个位置  1.24.4

pandas == 1.0.1

sklearn == 0.22.1

pip install torch-geometric==1.4.3 -f

# Thanks to the works of compared baseline methods: KDHR and SMGCN