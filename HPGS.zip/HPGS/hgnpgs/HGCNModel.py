import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score
import torch
import torch.nn as nn
import torch.nn.functional as F

from layers.layers import FermiDiracDecoder
import layers.hyp_layers as hyp_layers
import manifolds
import models.encoders as encoders
from models.decoders import model2decoder



# class BaseModel(nn.Module):
#     """
#     Base model for graph embedding tasks.
#     """
#
#     def __init__(self,n_nodes,feat_dim):
#         super(BaseModel, self).__init__()
#         self.c = torch.tensor([1.])
#         self.manifold_name = 'PoincareBall'
#         # if args.c is not None:
#         #     self.c = torch.tensor([1.])
#         #     if not args.cuda == -1:
#         #         self.c = self.c.to('cuda')
#         # else:
#         #     self.c = nn.Parameter(torch.Tensor([1.]))
#         self.manifold = getattr(manifolds, self.manifold_name)()
#         if self.manifold.name == 'Hyperboloid':
#             feat_dim = feat_dim + 1
#         self.nnodes = n_nodes
#         self.encoder = getattr(encoders, 'HGCN')(self.c)
#
#     def encode(self, x, adj):
#         if self.manifold.name == 'Hyperboloid':
#             o = torch.zeros_like(x)
#             x = torch.cat([o[:, 0:1], x], dim=1)
#         h = self.encoder.encode(x, adj)
#         return h
#
#     def compute_metrics(self, embeddings, data, split):
#         raise NotImplementedError
#
#     def init_metric_dict(self):
#         raise NotImplementedError
#
#     def has_improved(self, m1, m2):
#         raise NotImplementedError


class NCModel(nn.Module):
    """
    Base model for node classification task.
    """

    def __init__(self, n_nodes,output_dim):
        super(NCModel, self).__init__()
        self.c = torch.tensor([2.])
        self.manifold= 'PoincareBall'
        self.encoder = getattr(encoders, 'HGCN')(self.c)
        self.decoder = model2decoder['HGCN'](self.c)
    def encode(self, x, adj):
        if self.manifold == 'Hyperboloid':
            o = torch.zeros_like(x)
            x = torch.cat([o[:, 0:1], x], dim=1)
        h = self.encoder.encode(x, adj)
        return h

    def decode(self, h, adj):
        output = self.decoder.decode(h, adj)
        return output
        # return F.log_softmax(output[idx], dim=1)

    def compute_metrics(self, embeddings, data):
        # idx = data[f'idx_{split}']
        # output = self.decode(embeddings, data['adj_train_norm'])
        output = self.decode(embeddings,data)
        # loss = F.nll_loss(output, data['labels'][idx], self.weights)
        # acc, f1 = acc_f1(output, data['labels'][idx], average=self.f1_average)
        # metrics = {'loss': loss, 'acc': acc, 'f1': f1}
        return output
class HGCNHR(torch.nn.Module):
    def __init__(self, ss_num, hh_num, sh_num, embedding_dim, batchSize):
        super(HGCNHR, self).__init__()
        self.batchSize = batchSize
        # self.drop = drop

        self.SH_embedding = torch.nn.Embedding(sh_num, embedding_dim)
        self.SS_embedding = torch.nn.Embedding(ss_num,embedding_dim)
        self.HH_embedding = torch.nn.Embedding(sh_num,embedding_dim)

        # S-H 图所需的网络
        # S
        self.HGCNSS_Embedding=NCModel(n_nodes=ss_num,output_dim=embedding_dim)
        self.HGCNSH_Embedding = NCModel(n_nodes=sh_num,output_dim=embedding_dim)
        self.HGCNSH_Embedding2 = NCModel(n_nodes=sh_num, output_dim=embedding_dim)
        self.HGCNHH_Embedding=NCModel(n_nodes=hh_num,output_dim=embedding_dim)
        self.sh_ems=torch.nn.Linear(32,32)
        self.SH_mlp_1 = torch.nn.Linear(32, 32)

        self.SH_bn_1_h = torch.nn.BatchNorm1d(32)
        self.SH_tanh_1_h = torch.nn.Tanh()

        self.concatsLinear = torch.nn.Linear(32*2,32)
        self.concathLinear = torch.nn.Linear(32*2,32)


        self.L = torch.nn.Linear(32+27,32)#32+27  editby zcy
        # self.L = torch.nn.Linear(32, 32)  # 32+27
        self.mlp = torch.nn.Linear(32, 32)
        self.SI_bn = torch.nn.BatchNorm1d(32)
        self.relu = torch.nn.ReLU()


    def forward(self, x_SH, Spare_SH,x_SS,Spare_SS,x_HH,Spare_HH,prescription, kgOneHot):
        # S-H图搭建
        # 第一层
        #症状-中药二部图表示
        x_SH1 = self.SH_embedding(x_SH.long())
        x_SH2 = self.HGCNSH_Embedding.encode(x_SH1.squeeze(), Spare_SH)
        x_SH2=self.HGCNSH_Embedding.compute_metrics(x_SH2,Spare_SH)
        x_SH4 = self.HGCNSH_Embedding2.encode(x_SH2,Spare_SH)#20240330
        x_SH5 = self.HGCNSH_Embedding2.compute_metrics(x_SH4,Spare_SH)#20240330
        x_SH3 = self.sh_ems(x_SH1.squeeze())
        x_SH2 = (x_SH2+x_SH3+x_SH5)/3.0
        x_SH2 = self.SH_mlp_1(x_SH2)
        x_SH2=self.SH_bn_1_h(x_SH2)
        x_SH2 = self.SH_tanh_1_h(x_SH2)
        #SS 症状同构图表示
        x_ss1 = self.SS_embedding(x_SS.long())
        x_ss2 = self.HGCNSS_Embedding.encode(x_ss1.squeeze(), Spare_SS)
        x_ss2 = self.HGCNSS_Embedding.compute_metrics(x_ss2, Spare_SS)
        #HH 中药同构图表示
        x_hh1 = self.HH_embedding(x_HH.long())
        x_hh2 = self.HGCNHH_Embedding.encode(x_hh1.squeeze(),Spare_HH)
        x_hh2 = self.HGCNHH_Embedding.compute_metrics(x_hh2,Spare_HH)
        x_hh2 = torch.cat((x_hh2.float(), kgOneHot), dim=-1)

        x_hh2 = self.L(x_hh2)
        #特征融合方法concat()
        # concat
        #es = torch.concat([x_SH2[:390],x_ss2],dim=1)
        es = torch.cat([x_SH2[:390], x_ss2], dim=1)
        es = self.concatsLinear(es)
        # es =  x_SH2[:390]
        #eh = torch.concat([x_SH2[390:], x_hh2], dim=1)
        eh = torch.cat([x_SH2[390:],x_hh2],dim=1)
        eh = self.concathLinear(eh)
        #特征融合方法 sum()
        # es = x_SH2[:390] + x_ss2
        # eh = x_SH2[390:] + x_hh2
        #特征融合方法 Mean()
        # es = (x_SH2[:390] + x_ss2)/2.0
        # eh = (x_SH2[390:] + x_hh2)/2.0

        es = es.view(390, -1)
        #证候归纳 Mean() zcy
        e_synd = torch.mm(prescription, es)  # prescription * es
        # batch*1
        preSum = prescription.sum(dim=1).view(-1, 1)
        # batch*dim
        e_synd_norm = e_synd / preSum
        e_synd_norm = self.mlp(e_synd_norm)
        e_synd_norm = e_synd_norm.view(-1, 32)
        e_synd_norm = self.SI_bn(e_synd_norm)
        e_synd_norm = self.relu(e_synd_norm)

        # batch*dim
        # batch*dim dim*805 => batch*805
        #中药预测层
        eh = eh.view(805, -1)
        pre = torch.mm(e_synd_norm, eh.t()) #3-33

        # x_SH3 = self.SH_mlp_1(x_SH2)
        # x_SH4 = x_SH3.view(1195, -1)
        # 第二层

        # x_SH6 = x_SH6.view(-1, 256)
        # 第三层
        # x_SH7 = self.convSH_TostudyS_3(x_SH6, edge_index_SH)

        return pre